<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('plugin_installer_logs', function (Blueprint $table) {
            $table->id();
            $table->string('server_uuid', 36)->index();
            $table->string('plugin_id');
            $table->string('plugin_name')->nullable();
            $table->enum('source', ['modrinth', 'hangar', 'spigot']);
            $table->enum('status', ['installed', 'failed'])->default('installed');
            $table->string('installed_by')->nullable(); // email hoặc 'admin'
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plugin_installer_logs');
    }
};
