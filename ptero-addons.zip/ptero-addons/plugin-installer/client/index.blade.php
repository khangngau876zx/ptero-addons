@extends('layouts.base')

@section('title', 'Plugin Installer — ' . $server->name)

@section('content')
<div class="plugin-installer-wrap">
    {{-- Header --}}
    <div class="pi-header">
        <h2>🔌 Plugin Installer</h2>
        <p>Server: <strong>{{ $server->name }}</strong></p>
    </div>

    {{-- Source Tabs --}}
    <div class="pi-tabs">
        <button class="pi-tab active" data-source="modrinth">Modrinth</button>
        <button class="pi-tab" data-source="hangar">Hangar</button>
        <button class="pi-tab" data-source="spigot">SpigotMC</button>
    </div>

    {{-- Search Bar --}}
    <div class="pi-search">
        <input type="text" id="piSearch" placeholder="Tìm plugin... (EssentialsX, WorldGuard...)" autocomplete="off">
        <button id="piSearchBtn">Tìm kiếm</button>
    </div>

    {{-- Results --}}
    <div id="piResults"></div>

    {{-- Install History --}}
    <div class="pi-history">
        <h4>📋 Lịch sử cài đặt</h4>
        @if($logs->isEmpty())
            <p class="pi-empty">Chưa có plugin nào được cài.</p>
        @else
            <table class="pi-table">
                <thead>
                    <tr><th>Plugin</th><th>Nguồn</th><th>Bởi</th><th>Thời gian</th></tr>
                </thead>
                <tbody>
                    @foreach($logs as $log)
                    <tr>
                        <td>{{ $log->plugin_name ?? $log->plugin_id }}</td>
                        <td><span class="pi-badge pi-badge-{{ $log->source }}">{{ strtoupper($log->source) }}</span></td>
                        <td>{{ $log->installed_by }}</td>
                        <td>{{ \Carbon\Carbon::parse($log->created_at)->diffForHumans() }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</div>

{{-- Toast --}}
<div id="piToast" class="pi-toast"></div>

<style>
.plugin-installer-wrap { max-width: 860px; margin: 0 auto; padding: 24px 16px; font-family: 'Segoe UI', sans-serif; }
.pi-header { margin-bottom: 20px; }
.pi-header h2 { font-size: 22px; margin: 0 0 4px; }
.pi-header p { margin: 0; color: #888; font-size: 13px; }

.pi-tabs { display: flex; gap: 8px; margin-bottom: 16px; }
.pi-tab {
    padding: 7px 18px; border-radius: 20px; border: 1px solid #ddd;
    background: #fff; cursor: pointer; font-size: 13px; font-weight: 500;
    transition: all 0.2s;
}
.pi-tab.active { background: #2196F3; color: #fff; border-color: #2196F3; }

.pi-search { display: flex; gap: 8px; margin-bottom: 20px; }
.pi-search input {
    flex: 1; padding: 10px 14px; border: 1px solid #ccc; border-radius: 6px;
    font-size: 14px; outline: none;
}
.pi-search input:focus { border-color: #2196F3; box-shadow: 0 0 0 3px rgba(33,150,243,0.12); }
.pi-search button {
    padding: 10px 20px; background: #2196F3; color: #fff;
    border: none; border-radius: 6px; font-size: 14px; cursor: pointer;
}
.pi-search button:hover { background: #1976D2; }

#piResults { margin-bottom: 30px; }
.pi-card {
    display: flex; align-items: center; gap: 14px;
    border: 1px solid #e8e8e8; border-radius: 8px;
    padding: 14px; margin-bottom: 10px; background: #fff;
    transition: box-shadow 0.2s;
}
.pi-card:hover { box-shadow: 0 2px 10px rgba(0,0,0,0.09); }
.pi-icon {
    width: 52px; height: 52px; border-radius: 8px;
    object-fit: cover; background: #eee; flex-shrink: 0;
}
.pi-icon-ph {
    width: 52px; height: 52px; border-radius: 8px; flex-shrink: 0;
    background: linear-gradient(135deg, #2196F3, #0D47A1);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
}
.pi-info { flex: 1; min-width: 0; }
.pi-info strong { font-size: 15px; display: block; margin-bottom: 3px; }
.pi-info p { margin: 0; font-size: 12px; color: #777; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.pi-meta { font-size: 11px; color: #aaa; margin-top: 4px; }
.pi-install-btn {
    padding: 8px 16px; background: #43A047; color: #fff;
    border: none; border-radius: 6px; cursor: pointer; font-size: 13px; white-space: nowrap;
}
.pi-install-btn:hover { background: #2E7D32; }
.pi-install-btn:disabled { background: #aaa; cursor: not-allowed; }

.pi-spinner { text-align: center; padding: 30px; color: #888; }
.pi-empty { color: #aaa; font-size: 13px; }

.pi-history h4 { margin-bottom: 12px; font-size: 15px; }
.pi-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pi-table th { text-align: left; padding: 8px 10px; border-bottom: 2px solid #eee; color: #555; }
.pi-table td { padding: 8px 10px; border-bottom: 1px solid #f0f0f0; }
.pi-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
.pi-badge-modrinth { background: #1bd96a20; color: #1a7a43; }
.pi-badge-hangar { background: #e3f2fd; color: #1565c0; }
.pi-badge-spigot { background: #fff3e0; color: #bf360c; }

.pi-toast {
    position: fixed; bottom: 24px; right: 24px;
    padding: 12px 20px; border-radius: 8px; color: #fff; font-size: 14px;
    opacity: 0; pointer-events: none; transition: opacity 0.3s;
    z-index: 9999; max-width: 320px;
}
.pi-toast.show { opacity: 1; }
.pi-toast.success { background: #43A047; }
.pi-toast.error { background: #e53935; }
</style>

<script>
const serverUuid = '{{ $server->uuid }}';
let activeSource = 'modrinth';

document.querySelectorAll('.pi-tab').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.pi-tab').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        activeSource = this.dataset.source;
    });
});

document.getElementById('piSearchBtn').addEventListener('click', doSearch);
document.getElementById('piSearch').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

async function doSearch() {
    const q = document.getElementById('piSearch').value.trim();
    if (!q) return;

    const out = document.getElementById('piResults');
    out.innerHTML = '<div class="pi-spinner">⏳ Đang tìm kiếm...</div>';

    try {
        const res  = await fetch(`/servers/${serverUuid}/plugin-installer/search?query=${encodeURIComponent(q)}&source=${activeSource}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await res.json();

        if (!data.success || !data.results?.length) {
            out.innerHTML = '<p class="pi-empty">Không tìm thấy plugin nào phù hợp.</p>';
            return;
        }

        out.innerHTML = data.results.map(p => `
            <div class="pi-card">
                ${p.icon
                    ? `<img class="pi-icon" src="${p.icon}" onerror="this.outerHTML='<div class=pi-icon-ph>🔌</div>'">`
                    : `<div class="pi-icon-ph">🔌</div>`
                }
                <div class="pi-info">
                    <strong>${p.name}</strong>
                    <p>${p.description}</p>
                    <div class="pi-meta">👤 ${p.author} &nbsp;•&nbsp; ⬇️ ${p.downloads?.toLocaleString() ?? '?'}</div>
                </div>
                <button class="pi-install-btn"
                    data-id="${p.id}"
                    data-name="${p.name}"
                    data-source="${p.source}">
                    ⬇ Cài đặt
                </button>
            </div>
        `).join('');

        document.querySelectorAll('.pi-install-btn').forEach(btn => {
            btn.addEventListener('click', async function() {
                this.disabled = true;
                this.textContent = '⏳ Đang cài...';

                try {
                    const res  = await fetch(`/servers/${serverUuid}/plugin-installer/install`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        body: JSON.stringify({
                            plugin_id: this.dataset.id,
                            plugin_name: this.dataset.name,
                            source: this.dataset.source,
                        }),
                    });
                    const data = await res.json();
                    if (data.success) {
                        showToast(data.message, 'success');
                        this.textContent = '✅ Đã cài';
                    } else {
                        showToast(data.error || 'Lỗi cài đặt!', 'error');
                        this.disabled = false;
                        this.textContent = '⬇ Cài đặt';
                    }
                } catch (e) {
                    showToast('Lỗi kết nối!', 'error');
                    this.disabled = false;
                    this.textContent = '⬇ Cài đặt';
                }
            });
        });
    } catch (e) {
        out.innerHTML = `<p class="pi-empty" style="color:#e53935">Lỗi: ${e.message}</p>`;
    }
}

function showToast(msg, type) {
    const t = document.getElementById('piToast');
    t.textContent = msg;
    t.className = `pi-toast ${type} show`;
    setTimeout(() => t.classList.remove('show'), 3500);
}
</script>
@endsection
