<?php

use Illuminate\Support\Facades\Route;
use App\Extensions\plugin-installer\Controllers\AdminController;

Route::prefix('/plugin-installer')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('admin.plugin-installer.index');
    Route::get('/search/modrinth', [AdminController::class, 'searchModrinth'])->name('admin.plugin-installer.modrinth');
    Route::get('/search/hangar', [AdminController::class, 'searchHangar'])->name('admin.plugin-installer.hangar');
    Route::post('/install', [AdminController::class, 'installPlugin'])->name('admin.plugin-installer.install');
});
