<?php

use Illuminate\Support\Facades\Route;
use App\Extensions\plugin-installer\Controllers\ClientController;

Route::prefix('/servers/{uuid}/plugin-installer')->group(function () {
    Route::get('/', [ClientController::class, 'index'])->name('client.plugin-installer.index');
    Route::get('/search', [ClientController::class, 'search'])->name('client.plugin-installer.search');
    Route::post('/install', [ClientController::class, 'install'])->name('client.plugin-installer.install');
});
