@extends('layouts.admin')
@include('partials/admin.nav', ['activeTab' => 'plugin-installer'])

@section('title', 'Plugin Installer')

@section('content-header')
    <h1>Plugin Installer <small>Cài plugin Minecraft tự động</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Plugin Installer</li>
    </ol>
@endsection

@section('content')
<div class="row">
    {{-- Search Panel --}}
    <div class="col-md-8">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-search"></i> Tìm kiếm Plugin</h3>
            </div>
            <div class="box-body">
                {{-- Source Tabs --}}
                <ul class="nav nav-tabs" id="sourceTabs">
                    <li class="active"><a href="#" data-source="modrinth" class="source-tab">
                        <img src="https://cdn.modrinth.com/modrinth-new.svg" height="16"> Modrinth
                    </a></li>
                    <li><a href="#" data-source="hangar" class="source-tab">
                        🪶 Hangar (Paper)
                    </a></li>
                    <li><a href="#" data-source="spigot" class="source-tab">
                        🕷 SpigotMC
                    </a></li>
                </ul>

                <div style="margin-top:15px;">
                    <div class="input-group">
                        <input type="text" id="searchInput" class="form-control" placeholder="Nhập tên plugin... (vd: EssentialsX, WorldEdit)">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" id="searchBtn">
                                <i class="fa fa-search"></i> Tìm
                            </button>
                        </span>
                    </div>
                </div>

                <div id="searchResults" style="margin-top:15px;"></div>
            </div>
        </div>
    </div>

    {{-- Server Selector --}}
    <div class="col-md-4">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-server"></i> Chọn Server</h3>
            </div>
            <div class="box-body">
                <select id="serverSelect" class="form-control">
                    <option value="">-- Chọn server --</option>
                    @foreach($servers as $server)
                        <option value="{{ $server->uuid }}">
                            {{ $server->name }} ({{ $server->uuid }})
                        </option>
                    @endforeach
                </select>
                <p class="text-muted" style="margin-top:8px; font-size:12px;">
                    Plugin sẽ được tải vào thư mục <code>/plugins</code> của server đã chọn.
                </p>
            </div>
        </div>

        <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-history"></i> Gần đây</h3>
            </div>
            <div class="box-body" id="recentInstalls">
                <p class="text-muted">Chưa có plugin nào được cài.</p>
            </div>
        </div>
    </div>
</div>

{{-- Install Modal --}}
<div class="modal fade" id="installModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                <h4 class="modal-title">Xác nhận cài đặt</h4>
            </div>
            <div class="modal-body">
                <p>Bạn muốn cài plugin <strong id="modalPluginName"></strong> vào server <strong id="modalServerName"></strong>?</p>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    Cần restart server sau khi cài để plugin hoạt động.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-success" id="confirmInstall">
                    <i class="fa fa-download"></i> Cài đặt
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.plugin-card {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 12px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 12px;
    background: #fff;
    transition: box-shadow 0.2s;
}
.plugin-card:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.12); }
.plugin-icon {
    width: 48px; height: 48px;
    border-radius: 6px; object-fit: cover;
    background: #eee; flex-shrink: 0;
}
.plugin-icon-placeholder {
    width: 48px; height: 48px;
    border-radius: 6px;
    background: linear-gradient(135deg, #3c8dbc, #2c6e9c);
    display: flex; align-items: center; justify-content: center;
    color: white; font-size: 20px; flex-shrink: 0;
}
.plugin-info { flex: 1; min-width: 0; }
.plugin-info h5 { margin: 0 0 4px; font-weight: 600; }
.plugin-info p { margin: 0; font-size: 12px; color: #777; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.plugin-meta { font-size: 11px; color: #999; margin-top: 3px; }
.source-tab.active-tab { font-weight: bold; border-bottom: 2px solid #3c8dbc; }
.nav-tabs > li > a { cursor: pointer; }
</style>

<script>
let currentSource = 'modrinth';
let pendingInstall = null;

// Tab switching
document.querySelectorAll('.source-tab').forEach(tab => {
    tab.addEventListener('click', function(e) {
        e.preventDefault();
        currentSource = this.dataset.source;
        document.querySelectorAll('.source-tab').forEach(t => t.classList.remove('active-tab'));
        this.classList.add('active-tab');
        document.querySelectorAll('.nav-tabs > li').forEach(li => li.classList.remove('active'));
        this.closest('li').classList.add('active');
    });
});

// Search
document.getElementById('searchBtn').addEventListener('click', doSearch);
document.getElementById('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

async function doSearch() {
    const query = document.getElementById('searchInput').value.trim();
    if (!query) return;

    const resultsDiv = document.getElementById('searchResults');
    resultsDiv.innerHTML = '<div class="text-center"><i class="fa fa-spinner fa-spin fa-2x"></i><p>Đang tìm kiếm...</p></div>';

    try {
        const url = currentSource === 'modrinth'
            ? `/admin/plugin-installer/search/modrinth?query=${encodeURIComponent(query)}`
            : `/admin/plugin-installer/search/hangar?query=${encodeURIComponent(query)}`;

        const res  = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const data = await res.json();

        if (!data.success || !data.results.length) {
            resultsDiv.innerHTML = '<p class="text-muted text-center">Không tìm thấy plugin nào.</p>';
            return;
        }

        resultsDiv.innerHTML = data.results.map(p => `
            <div class="plugin-card">
                ${p.icon
                    ? `<img class="plugin-icon" src="${p.icon}" onerror="this.style.display='none'">`
                    : `<div class="plugin-icon-placeholder">🔌</div>`
                }
                <div class="plugin-info">
                    <h5>${p.name}</h5>
                    <p>${p.description}</p>
                    <div class="plugin-meta">
                        👤 ${p.author} &nbsp;•&nbsp; ⬇️ ${p.downloads?.toLocaleString() ?? '?'} lượt tải
                    </div>
                </div>
                <button class="btn btn-sm btn-success install-btn"
                    data-id="${p.id}"
                    data-name="${p.name}"
                    data-source="${p.source}">
                    <i class="fa fa-download"></i> Cài
                </button>
            </div>
        `).join('');

        document.querySelectorAll('.install-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const serverId = document.getElementById('serverSelect').value;
                if (!serverId) {
                    alert('Vui lòng chọn server trước!');
                    return;
                }
                pendingInstall = {
                    plugin_id: this.dataset.id,
                    plugin_name: this.dataset.name,
                    source: this.dataset.source,
                    server_id: serverId,
                };
                document.getElementById('modalPluginName').textContent = this.dataset.name;
                document.getElementById('modalServerName').textContent =
                    document.getElementById('serverSelect').options[document.getElementById('serverSelect').selectedIndex].text;
                $('#installModal').modal('show');
            });
        });
    } catch (e) {
        resultsDiv.innerHTML = `<div class="alert alert-danger">Lỗi: ${e.message}</div>`;
    }
}

// Confirm install
document.getElementById('confirmInstall').addEventListener('click', async function() {
    if (!pendingInstall) return;
    this.disabled = true;
    this.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Đang cài...';

    try {
        const res  = await fetch('/admin/plugin-installer/install', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: JSON.stringify(pendingInstall),
        });
        const data = await res.json();

        $('#installModal').modal('hide');
        if (data.success) {
            toastr.success(data.message);
        } else {
            toastr.error(data.error || 'Cài đặt thất bại!');
        }
    } catch (e) {
        toastr.error('Lỗi kết nối: ' + e.message);
    } finally {
        this.disabled = false;
        this.innerHTML = '<i class="fa fa-download"></i> Cài đặt';
        pendingInstall = null;
    }
});
</script>
@endsection
