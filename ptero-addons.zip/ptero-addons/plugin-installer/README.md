# 🔌 Plugin Installer — Pterodactyl Addon

Tự động tìm kiếm và cài plugin Minecraft từ **Modrinth**, **Hangar** và **SpigotMC** trực tiếp vào server.

## ✨ Tính năng

- 🔍 Tìm kiếm từ 3 nguồn: Modrinth, Hangar (Paper), SpigotMC
- ⬇️ Cài 1 click vào `/plugins` qua Wings API
- 👑 **Admin Panel** — quản lý tất cả server
- 👤 **Client Panel** — user tự cài cho server của họ
- 📋 Lịch sử cài đặt lưu DB theo từng server
- 🔒 Kiểm tra quyền user trước khi cho cài

## 📥 Cài đặt

```bash
cd /var/www/pterodactyl

wget https://github.com/USERNAME/ptero-addons/releases/latest/download/plugin-installer.blueprint

php artisan blueprint:install plugin-installer
php artisan migrate
php artisan optimize:clear
```

## 🗑️ Gỡ cài đặt

```bash
php artisan blueprint:remove plugin-installer
php artisan migrate:rollback
php artisan optimize:clear
```

## 📋 Yêu cầu

- Blueprint `>= 0.8`
- Pterodactyl `>= 1.11`
- PHP `>= 8.1`
- GuzzleHttp (đã có sẵn trong Pterodactyl)

## ⚠️ Lưu ý

- SpigotMC **premium plugins** không tải được (yêu cầu mua)
- Cần **restart server** sau khi cài plugin để có hiệu lực
- User cần quyền `control.start` mới được phép cài
