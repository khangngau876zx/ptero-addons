<?php

namespace App\Extensions\plugin-installer\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Models\Server;
use GuzzleHttp\Client;

class ClientController extends Controller
{
    private Client $http;

    public function __construct()
    {
        $this->http = new Client(['timeout' => 15]);
    }

    public function index(Request $request, string $uuid)
    {
        $server = Server::where('uuid', $uuid)->firstOrFail();
        $logs   = \DB::table('plugin_installer_logs')
            ->where('server_uuid', $uuid)
            ->orderByDesc('created_at')
            ->limit(20)
            ->get();

        return view('blueprint.extensions.plugin-installer.client.index', compact('server', 'logs'));
    }

    public function search(Request $request, string $uuid): JsonResponse
    {
        $query  = $request->input('query');
        $source = $request->input('source', 'modrinth');

        try {
            $results = match($source) {
                'modrinth' => $this->searchModrinth($query),
                'hangar'   => $this->searchHangar($query),
                'spigot'   => $this->searchSpigot($query),
                default    => [],
            };
            return response()->json(['success' => true, 'results' => $results]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function install(Request $request, string $uuid): JsonResponse
    {
        $request->validate([
            'source'    => 'required|in:modrinth,hangar,spigot',
            'plugin_id' => 'required|string',
            'plugin_name' => 'required|string',
        ]);

        $server = Server::where('uuid', $uuid)->firstOrFail();

        // Kiểm tra quyền của user với server này
        if (!$request->user()->can('control.start', $server)) {
            return response()->json(['success' => false, 'error' => 'Bạn không có quyền cài plugin trên server này.'], 403);
        }

        try {
            $downloadUrl = match($request->source) {
                'modrinth' => $this->getModrinthDownloadUrl($request->plugin_id),
                'hangar'   => $this->getHangarDownloadUrl($request->plugin_id),
                'spigot'   => "https://api.spiget.org/v2/resources/{$request->plugin_id}/download",
            };

            if (!$downloadUrl) {
                return response()->json(['success' => false, 'error' => 'Không tìm được link tải.'], 400);
            }

            $wingsUrl   = "https://{$server->node->fqdn}:{$server->node->daemon_port}";
            $wingsToken = $server->node->daemon_token;

            $this->http->post("{$wingsUrl}/api/servers/{$server->uuid}/files/pull", [
                'headers' => [
                    'Authorization' => "Bearer {$wingsToken}",
                    'Content-Type'  => 'application/json',
                ],
                'json' => [
                    'url'       => $downloadUrl,
                    'directory' => '/plugins',
                ],
            ]);

            \DB::table('plugin_installer_logs')->insert([
                'server_uuid'  => $server->uuid,
                'plugin_id'    => $request->plugin_id,
                'plugin_name'  => $request->plugin_name,
                'source'       => $request->source,
                'status'       => 'installed',
                'installed_by' => $request->user()->email,
                'created_at'   => now(),
                'updated_at'   => now(),
            ]);

            return response()->json(['success' => true, 'message' => "Plugin {$request->plugin_name} đang được cài đặt!"]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    private function searchModrinth(string $query): array
    {
        $res  = $this->http->get("https://api.modrinth.com/v2/search", [
            'query' => ['query' => $query, 'facets' => '[["project_type:plugin"]]', 'limit' => 10]
        ]);
        $data = json_decode($res->getBody(), true);
        return array_map(fn($h) => [
            'id' => $h['project_id'], 'name' => $h['title'],
            'description' => $h['description'], 'author' => $h['author'],
            'downloads' => $h['downloads'], 'icon' => $h['icon_url'] ?? null,
            'source' => 'modrinth',
        ], $data['hits'] ?? []);
    }

    private function searchHangar(string $query): array
    {
        $res  = $this->http->get("https://hangar.papermc.io/api/v1/projects", [
            'query' => ['q' => $query, 'limit' => 10]
        ]);
        $data = json_decode($res->getBody(), true);
        return array_map(fn($p) => [
            'id'          => "{$p['namespace']['owner']}/{$p['namespace']['slug']}",
            'name'        => $p['name'],
            'description' => $p['description'],
            'author'      => $p['namespace']['owner'],
            'downloads'   => $p['stats']['downloads'],
            'icon'        => $p['avatarUrl'] ?? null,
            'source'      => 'hangar',
        ], $data['result'] ?? []);
    }

    private function searchSpigot(string $query): array
    {
        $res  = $this->http->get("https://api.spiget.org/v2/search/resources/{$query}", [
            'query' => ['size' => 10, 'sort' => '-downloads']
        ]);
        $data = json_decode($res->getBody(), true);
        return array_map(fn($r) => [
            'id'          => (string)$r['id'],
            'name'        => $r['name'],
            'description' => $r['tag'] ?? '',
            'author'      => $r['author']['name'] ?? 'Unknown',
            'downloads'   => $r['downloads'],
            'icon'        => isset($r['icon']['url']) ? "https://www.spigotmc.org/{$r['icon']['url']}" : null,
            'source'      => 'spigot',
        ], is_array($data) ? $data : []);
    }

    private function getModrinthDownloadUrl(string $projectId): ?string
    {
        $res      = $this->http->get("https://api.modrinth.com/v2/project/{$projectId}/version", [
            'query' => ['loaders' => '["bukkit","spigot","paper"]', 'limit' => 1]
        ]);
        $versions = json_decode($res->getBody(), true);
        return $versions[0]['files'][0]['url'] ?? null;
    }

    private function getHangarDownloadUrl(string $slug): ?string
    {
        [$owner, $name] = explode('/', $slug, 2);
        $res     = $this->http->get("https://hangar.papermc.io/api/v1/projects/{$owner}/{$name}/latestrelease");
        $version = trim($res->getBody());
        return "https://hangar.papermc.io/api/v1/projects/{$owner}/{$name}/versions/{$version}/PAPER/download";
    }
}
