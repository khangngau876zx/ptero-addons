<?php

namespace App\Extensions\plugin-installer\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Models\Server;
use GuzzleHttp\Client;

class AdminController extends Controller
{
    private Client $http;

    public function __construct()
    {
        $this->http = new Client(['timeout' => 15]);
    }

    public function index()
    {
        $servers = Server::all();
        return view('blueprint.extensions.plugin-installer.admin.index', compact('servers'));
    }

    /**
     * Tìm plugin từ Modrinth
     */
    public function searchModrinth(Request $request): JsonResponse
    {
        $query = $request->input('query');
        try {
            $response = $this->http->get("https://api.modrinth.com/v2/search", [
                'query' => [
                    'query'  => $query,
                    'facets' => '[["project_type:plugin"],["categories:bukkit"]]',
                    'limit'  => 10,
                ]
            ]);
            $data = json_decode($response->getBody(), true);
            $results = array_map(fn($hit) => [
                'id'          => $hit['project_id'],
                'name'        => $hit['title'],
                'description' => $hit['description'],
                'author'      => $hit['author'],
                'downloads'   => $hit['downloads'],
                'icon'        => $hit['icon_url'] ?? null,
                'source'      => 'modrinth',
                'url'         => "https://modrinth.com/plugin/{$hit['slug']}",
            ], $data['hits'] ?? []);

            return response()->json(['success' => true, 'results' => $results]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Tìm plugin từ Hangar (PaperMC)
     */
    public function searchHangar(Request $request): JsonResponse
    {
        $query = $request->input('query');
        try {
            $response = $this->http->get("https://hangar.papermc.io/api/v1/projects", [
                'query' => [
                    'q'       => $query,
                    'limit'   => 10,
                    'offset'  => 0,
                    'orderBy' => 'downloads',
                ]
            ]);
            $data = json_decode($response->getBody(), true);
            $results = array_map(fn($p) => [
                'id'          => $p['namespace']['slug'],
                'name'        => $p['name'],
                'description' => $p['description'],
                'author'      => $p['namespace']['owner'],
                'downloads'   => $p['stats']['downloads'],
                'icon'        => $p['avatarUrl'] ?? null,
                'source'      => 'hangar',
                'url'         => "https://hangar.papermc.io/{$p['namespace']['owner']}/{$p['namespace']['slug']}",
            ], $data['result'] ?? []);

            return response()->json(['success' => true, 'results' => $results]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Tải và cài plugin vào server qua Wings API
     */
    public function installPlugin(Request $request): JsonResponse
    {
        $request->validate([
            'server_id' => 'required|string',
            'source'    => 'required|in:modrinth,hangar,spigot',
            'plugin_id' => 'required|string',
        ]);

        $server = Server::where('uuid', $request->server_id)->firstOrFail();

        try {
            // Lấy download URL theo nguồn
            $downloadUrl = match($request->source) {
                'modrinth' => $this->getModrinthDownloadUrl($request->plugin_id),
                'hangar'   => $this->getHangarDownloadUrl($request->plugin_id),
                'spigot'   => $this->getSpigotDownloadUrl($request->plugin_id),
            };

            if (!$downloadUrl) {
                return response()->json(['success' => false, 'error' => 'Không tìm được link tải plugin.'], 400);
            }

            // Gửi lệnh tải file về thư mục plugins/ trên Wings
            $wingsUrl  = "https://{$server->node->fqdn}:{$server->node->daemon_port}";
            $wingsToken = $server->node->daemon_token;

            $this->http->post("{$wingsUrl}/api/servers/{$server->uuid}/files/pull", [
                'headers' => [
                    'Authorization' => "Bearer {$wingsToken}",
                    'Content-Type'  => 'application/json',
                ],
                'json' => [
                    'url'       => $downloadUrl,
                    'directory' => '/plugins',
                ],
            ]);

            // Ghi log vào DB
            \DB::table('plugin_installer_logs')->insert([
                'server_uuid' => $server->uuid,
                'plugin_id'   => $request->plugin_id,
                'source'      => $request->source,
                'status'      => 'installed',
                'installed_by'=> 'admin',
                'created_at'  => now(),
                'updated_at'  => now(),
            ]);

            return response()->json(['success' => true, 'message' => 'Plugin đang được cài đặt vào server!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    private function getModrinthDownloadUrl(string $projectId): ?string
    {
        $res = $this->http->get("https://api.modrinth.com/v2/project/{$projectId}/version", [
            'query' => ['loaders' => '["bukkit","spigot","paper"]', 'limit' => 1]
        ]);
        $versions = json_decode($res->getBody(), true);
        return $versions[0]['files'][0]['url'] ?? null;
    }

    private function getHangarDownloadUrl(string $slug): ?string
    {
        // slug dạng "Owner/ProjectName"
        [$owner, $name] = explode('/', $slug, 2);
        $res = $this->http->get("https://hangar.papermc.io/api/v1/projects/{$owner}/{$name}/latestrelease");
        $version = trim($res->getBody());
        return "https://hangar.papermc.io/api/v1/projects/{$owner}/{$name}/versions/{$version}/PAPER/download";
    }

    private function getSpigotDownloadUrl(string $resourceId): ?string
    {
        // SpigotMC yêu cầu login cho một số plugin, dùng spiget.org API thay thế
        return "https://api.spiget.org/v2/resources/{$resourceId}/download";
    }
}
