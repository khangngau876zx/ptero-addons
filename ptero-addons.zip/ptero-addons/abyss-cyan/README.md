# 🌌 Abyss Cyan — Pterodactyl Theme

Theme vũ trụ sâu thẳm cho Pterodactyl Panel với màu **cyan** làm điểm nhấn chính.

## ✨ Tính năng

- 🌟 **Stars background** — Sao nhấp nháy động trên nền vũ trụ
- 💎 **Glassmorphism** — Cards, modals có hiệu ứng kính mờ
- ⚡ **Scan line** — Đường sáng cyan chạy dọc màn hình
- 🎨 **Cyan glow** — Buttons, inputs, sidebar phát sáng khi hover
- 🔤 **Custom fonts** — Space Grotesk (UI) + JetBrains Mono (code/terminal)
- 🌈 **Nebula clouds** — Đám mây màu tím/cyan mờ trên nền
- 📱 **Responsive** — Hoạt động tốt trên mobile

## 🎨 Palette

| Tên | Hex | Dùng cho |
|-----|-----|----------|
| Void | `#04060f` | Nền chính |
| Deep | `#080d1a` | Panel/sidebar |
| Surface | `#0d1628` | Cards |
| Cyan Core | `#00e5ff` | Accent chính |
| Cyan Dim | `#00b8d4` | Accent phụ |
| Text | `#e8f4f8` | Chữ chính |

## 📥 Cài đặt

```bash
cd /var/www/pterodactyl

# Tải file
wget https://github.com/USERNAME/ptero-addons/releases/latest/download/abyss-cyan.blueprint

# Cài
php artisan blueprint:install abyss-cyan
php artisan optimize:clear
```

## 🗑️ Gỡ cài đặt

```bash
php artisan blueprint:remove abyss-cyan
php artisan optimize:clear
```

## 📋 Yêu cầu

- Blueprint `>= 0.8`
- Pterodactyl `>= 1.11`
