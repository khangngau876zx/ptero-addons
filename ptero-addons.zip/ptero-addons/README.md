# 🚀 Pterodactyl Addons

Blueprint addons cho Pterodactyl Panel — theme và tiện ích mở rộng.

## 📦 Danh sách Addon

| Addon | Phiên bản | Mô tả |
|-------|-----------|-------|
| [Abyss Cyan](#-abyss-cyan-theme) | 1.0.0 | Theme vũ trụ cyan tối |
| [Plugin Installer](#-plugin-installer) | 1.0.0 | Tự động cài plugin Minecraft |

---

## 🌌 Abyss Cyan Theme

Theme vũ trụ sâu thẳm với màu **cyan** làm điểm nhấn, hiệu ứng sao nhấp nháy và glassmorphism.

### Tính năng
- 🌟 Nền vũ trụ với sao nhấp nháy động
- 💎 Glassmorphism cards & modals
- ⚡ Scan line animation
- 🎨 Cyan glow trên buttons, inputs, sidebar
- 🔤 Font Space Grotesk + JetBrains Mono
- 📱 Responsive mobile

### Cài đặt
```bash
cd /var/www/pterodactyl
wget https://github.com/USERNAME/ptero-addons/releases/download/v1.0.0/abyss-cyan.blueprint
php artisan blueprint:install abyss-cyan
php artisan optimize:clear
```

### Preview
> Background: `#04060f` · Accent: `#00e5ff` · Style: Cosmic glassmorphism

---

## 🔌 Plugin Installer

Tự động tìm kiếm và cài plugin Minecraft từ nhiều nguồn vào server Pterodactyl.

### Tính năng
- 🔍 Tìm plugin từ **Modrinth**, **Hangar (Paper)**, **SpigotMC**
- ⬇️ Cài 1 click vào thư mục `/plugins`
- 👤 Hỗ trợ cả Admin Panel và Client Panel
- 📋 Lịch sử cài đặt theo từng server
- 🔒 Kiểm tra quyền user trước khi cài

### Cài đặt
```bash
cd /var/www/pterodactyl
wget https://github.com/USERNAME/ptero-addons/releases/download/v1.0.0/plugin-installer.blueprint
php artisan blueprint:install plugin-installer
php artisan migrate
php artisan optimize:clear
```

### Yêu cầu
- Pterodactyl Panel `>= 1.11`
- Blueprint Framework `>= 0.8`
- PHP `>= 8.1`

---

## ⚙️ Yêu cầu chung

- [Blueprint Framework](https://github.com/BlueprintFramework/framework) đã được cài
- Pterodactyl Panel `>= 1.11`

## 📥 Tải về

Xem [Releases](../../releases) để tải file `.blueprint` mới nhất.

## 🛠️ Gỡ cài đặt

```bash
php artisan blueprint:remove ADDON_ID
php artisan optimize:clear
```

## 📄 License

MIT License — tự do sử dụng và chỉnh sửa.
